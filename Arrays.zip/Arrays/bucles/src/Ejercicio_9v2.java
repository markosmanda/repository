
import java.util.concurrent.TimeUnit;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_9v2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        int horas=24;
        int minutos=60;
        int segundos = 60;
        for (int z = 0; z < horas; z++) {
            
            for (int i = 0; i < minutos; i++) {
                
                for (int j = 0; j < segundos; j++) {
                    
                    if ((i == 2) && (j > 0)) {
                        break;
                    }
                    if (z == 0){
                    System.out.println(i + ":" + j);
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    }else {
                    System.out.println(z + ":" + i + ":" + j);
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    }

                    
                    
                    TimeUnit.SECONDS.sleep(1);
                    
                }
            }
        }
    }
}
