
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        int combi = 0;
        int contador = 0;
        int contraseña = 1974;
        
        

        for (int i = 0; i < 4; i++) {
            contador++;
            System.out.print("Introduzca contraseña para acceder a caja fuerte: ");
            combi = Integer.parseInt(entrada.next());

            if (combi != contraseña) {
                System.out.println("No has accedido al sistema\n" + "su numero de intentos fallidos es: " + contador);
            }
            if (combi == contraseña) {
                System.out.println("Has podido acceder al sistema");
                break;
            }
        }

    }
}
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
    

    

