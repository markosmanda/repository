
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic her
        Scanner entrada = new Scanner (System.in);
        int num;
        int nume;
        
        System.out.print("Introduce el numero: ");
        num = Integer.parseInt(entrada.next());
        
        for ( nume=0;nume<=10;nume++){
        System.out.println("El resultado es: "+num*nume);
        }
    }
    
}
