
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        int numeros;
        int num = 0;
        int mayor = 0;
        int menor = 0;
        int cero = 0;

        System.out.print("Introduce La cantidad de numeros: ");
        numeros = Integer.parseInt(entrada.next());

        for (int i = 0; i < numeros; i++) {
            System.out.print("Introduce un numero: ");
            num = Integer.parseInt(entrada.next());
            if (num > 0) {
                mayor++;

            } else if (num < 0) {
                menor++;
            } else {
                cero++;
            }

        }
        System.out.println("El numero mayor de 0 introducido es: " + mayor);
        System.out.println("El numero menor de 0 introducido es: " + menor);
        System.out.println("El numero cero introducido es: " + cero);
    }

}
            
            
        
        
        
        
        
        
        
        
        
        
        
    
    

