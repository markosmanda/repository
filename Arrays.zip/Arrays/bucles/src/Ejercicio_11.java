
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author marcos.españa
 */
public class Ejercicio_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        String cadena;
        char num='\0';

        
        do {

        int suerte = 0;
        int malasuerte = 0;
            System.out.print("Introduce un numero: ");
            cadena = entrada.nextLine();

            for (int i = 0; i < cadena.length(); i++) {
                num = cadena.charAt(i);

                switch (num) {
                    case '2','5','8':
                        suerte++;
                        break;
                    case '1','3','4','6','7','9','0':
                        malasuerte++;
                        break;

                }

            }
            if (cadena.equals("e")) {
                System.out.println("Saliendo");
            }if(num=='e'){
                System.out.println("Error");
            }
            else {
                if (malasuerte >= suerte) {
                    System.out.println("El numero es de mala suerte");
                } else if (suerte > malasuerte) {
                    System.out.println("El numero da buena suerte");

                }
                
            }

        } while (cadena.charAt(0) != 'e');

    }
    
}