/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inicio;

import java.util.Scanner;

/**
 *
 * @author marcos.españa
 */
public class Iniciacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
//        
//        System.out.println("**** for ****");
//        for (int i=0;i<11;i++){
//            System.out.println("i vale: "+i);
//        }
//        
//        \n es salto de linea
            
//          System.out.println("\n\n**** while ****");
//        int i = 1;
//        while (i <= 10) {
//            System.out.println(i);
//            i++;
//        }

//        System.out.println("****do while****");
//        int i=1;
//                do{
//                    System.out.println(i);
//                    i++;
//                
//                }while(i<11);

            int num;
//          System.out.print("Introduce numeros: ");
//          num = Integer.parseInt(entrada.nextLine());
//          
//
//          
//          while (num>=0){
//              System.out.print("Numero positivo para continuar: ");
//              num=Integer.parseInt(entrada.nextLine());
//              
//              
//          }
//            do{
//            System.out.print("Numero positivo para continuar: ");
//            num=Integer.parseInt(entrada.next());
//            }while(num>0);


            
            
                  
            
    
    }
}
