/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inicio;

import java.util.Scanner;

/**
 *
 * @author marcos.españa
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int num;
        
//        do{
//            System.out.print("numero para continuar; ");
//            num=Integer.parseInt(entrada.next()) ;
//            if (num%2!=0){
//                break;
//                
//            }
//    } while (true);

//        for (int i=0;i<10;i++){
//            System.out.print("Numero par para continuar: ");
//            num=Integer.parseInt(entrada.next());
//            if (num%2!=0){
//                break;
//            }
//        }

//         for (int i=65 ;i<=90;i++){
//             System.out.print("letra: "+(char)i);
//              System.out.println((char)(i+32));
//         }
 for (int i=0;i>=10;i++){
        System.out.println("el resultado es: "+3*(5));
        }
                }
}
