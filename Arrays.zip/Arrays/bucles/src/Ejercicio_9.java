
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int num;
        int multi = 0;
        
        System.out.print("Introduce el numero: ");
        num = Integer.parseInt(entrada.next());
        
//
//        
//        for (int i=1 ; i<=num; i++){
//            System.out.println("");
//            for (int j = 1; j<=10; j++){
//                System.out.println(i+"*"+j+"-"+(i*j));
//            }
//            
//        }
//            
        for (int i=1 ; i<=num; i++){
            System.out.println("");
            int factorial = 1;
        
            for (int j=1 ; j <=i; j++){
                factorial = factorial * j;
            }
             System.out.println("el factorial de "+i+ " es = "+factorial);
        }
        
    }
    
}
