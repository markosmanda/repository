/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


import java.util.Scanner;

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);

        double num1, num2;
        int opcion;
        String tecla;
        double resultado;
        boolean activo = true;

        while (activo) {

            System.out.print("Introduce los numeros: ");
            num1 = Integer.parseInt(entrada.next());
            num2 = Integer.parseInt(entrada.next());
            boolean opcioncorrecta = false;
        
        while (opcioncorrecta==false){
            
            System.out.println("Opcion 1: SUMAR");
            System.out.println("Opcion 2: RESTAR");
            System.out.println("Opcion 3: MULTIPLICAR");
            System.out.println("Opcion 4: DIVIDIR");
            System.out.println("Opcion 5: SALIR");
            System.out.println("Elige la opcion: ");
            opcion = Integer.parseInt(entrada.next());

            
                switch (opcion) {
                    case 1:
                        resultado = num1 + num2;
                        System.out.println("el resultado es: " + resultado);
                        opcioncorrecta = true;
                        break;

                    case 2:
                        resultado = num1 - num2;
                        System.out.println("El resultado es: " + resultado);
                        opcioncorrecta = true;
                        break;

                    case 3:
                        resultado = num1 * num2;
                        System.out.println("El resultado es: " + resultado);
                        opcioncorrecta = true;
                        break;

                    case 4:
                        resultado = num1 / num2;
                        System.out.println("El resultado es: " + resultado);
                        opcioncorrecta = true;
                        
                        break;

                    case 5:
                        System.out.println("Saliendo");
                        activo = false;
                        opcioncorrecta = true;
                        break;
                    default:
                        
                        System.out.println("No es correcto");

        }
    }
}
}
}