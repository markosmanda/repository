
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author marcos.españa
 */
public class Ejercicio_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);

        int num;
        int negativo = 0;
        boolean cero = true;
        do {
            System.out.print("Introduce el numero: ");
            num = Integer.parseInt(entrada.next());
            if (num < 0) {
                negativo++;
            }
            
            if (num == 0) {
                System.out.println("El programa ha terminado");
                cero = false;
            }
            
        }while (cero);
        if (negativo==0){
                System.out.println("No has introducido numeros negativos");
        } else if (negativo>0){
            System.out.println("Has introducido numeros negativos");
        }
       
    }

}
