
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        
        int n;
//        int suma=0;
//        
//        System.out.print("Introduce el numero: ");
//        n = Integer.parseInt(entrada.next());
//        
//      for (int i=1;i<=n;i++){
//          suma=suma+i;}
//          System.out.println("La suma es: "+suma);
//        
//        int suma=0;
        
        System.out.println("Introduce el numero: ");
        n = Integer.parseInt(entrada.next());
        int factorial=1;
        for (int i=1;i<=n;i++){
            factorial=factorial*i;
            System.out.println("El resultado es: "+factorial);
        
    }
            
        
    }
    
}
