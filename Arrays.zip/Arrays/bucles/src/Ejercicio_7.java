
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author marcos.españa
 */
public class Ejercicio_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        char letra = 0;
        String entradaa = "";
        boolean espacio = true;
        do {
            System.out.print("Introduce la letra: ");
            entradaa = entrada.nextLine();
            letra = entradaa.charAt(0);
            if (letra == ' ') {
                espacio = false;
                System.out.println("No metas espacios, saliendo");
            } else {

                if ((letra == 'a') || (letra == 'e') || (letra == 'i') || (letra == 'o') || (letra == 'u')) {
                    System.out.println("La letra introducida es una vocal");

                } else {
                    System.out.println("La letra introducida no es una vocal");
                }
            }

        } while (espacio);
    }

}
