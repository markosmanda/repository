
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author marcos.españa
 */
public class Ejercicio_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        String correo = "";
        char letra = 0;
        char arroba = 0;
        char punto = 0;

        int posicion_arroba = 0;
        int posicion_punto = 0;

        boolean arroba2 = false;
        boolean punto2 = false;
        System.out.print("Introduce un correo: ");
        correo = entrada.nextLine();

        for (int i = 0; i < correo.length(); i++) {
            letra = correo.charAt(i);

            if (letra == '@') {
                posicion_arroba = i;
                arroba2 = true;

            } else if (letra == '.') {
                posicion_punto = i;
                punto2 = true;
            }

        }

        if ((arroba2 == true) && (punto2 == true)) {
            if (posicion_arroba < posicion_punto) {
                System.out.println("El correo es correcto");
            }else if (posicion_arroba > posicion_punto) {
                System.out.println("Orden incorrecto (. antes de @)");
            }
        } else {
            if (punto2 == false) {
                System.out.println("Falta el punto");

            } else if (arroba2 == false) {
                System.out.println("Falta el arroba");
            } 
        }

    }

}
                    
              
            

