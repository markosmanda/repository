/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_extra_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] numeros1 = {2, 8, 6, 7};
        int[] numeros2 = {2, 8, 7, 6};
        int contadorigual = 0;

        for (int i = 0; i < numeros1.length; i++) {

            for (int j = 0; j < numeros2.length; j++) {
                if (numeros1[i] == numeros2[j]) {
                    contadorigual++;
                }
            }
        }
        if (numeros1.length != numeros2.length) {
            System.out.println("Los arrays no tienen la misma longitud");
        }else if (contadorigual == numeros1.length) {
            System.out.println("Son iguales");
        } else {
            System.out.println("No son iguales");
        }
    }

}
