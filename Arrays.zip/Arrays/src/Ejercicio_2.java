
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int []num = new int [5];
        
        for(int i=0;i<num.length;i++){
            System.out.print("Introduce el numero: ");
            num[i]=Integer.parseInt(entrada.nextLine());
            
        }
        
        
        
        for(int i=0;i<num.length;i++){
//            System.out.printf("numeros[%d] %10d\n",i,num[i]);
            System.out.println("Arrey --> .["+num[i]);
    }
    }
    
}
