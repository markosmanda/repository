/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_extra_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] numeros1 = {2, 4, 6, 7};
        int[] numeros2 = {2, 4, 6, 7};
        boolean iguales = true;

        for (int i = 0; i < numeros1.length; i++) {
            if (numeros1[i] != numeros2[i]) {
                iguales = false;
                break;
            }

        }
        
        
        if (iguales == false) {
            System.out.println("No son iguales");
        }else {
            System.out.println("Son iguales");
        }
        
        
    }

}
