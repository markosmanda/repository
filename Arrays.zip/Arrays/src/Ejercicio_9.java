
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int []nombres = new int [5];
        int []edad = new int [5];
        String nombre="";
        
     
        for (int i=0;i<=nombres.length;i++){
            System.out.println("[* para terminar] Introduce el nombre del alumno: ");
            
            nombre=entrada.nextLine();
            
            
            
            System.out.println("Introduce la edad del alumno");
            edad[i]=Integer.parseInt(entrada.next());
            
           
            
            
            
            
        }for (int i=0;i<nombres.length;i++){
            System.out.println(nombres[i]);
            System.out.println(edad[i]);
            
        }
      }
    }
    

