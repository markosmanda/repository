/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int matriz[][] = new int[5][5];
        int sumafila = 0, sumacolumna = 0;

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                matriz[i][j] = (int) (Math.random() * 10);
            }

        }
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("   " + matriz[i][j] + "   ");

            }
            System.out.println("");
        }
        
        for (int fila=0;fila<5;fila++){
            sumafila=0;
            for (int columna =0;columna<5;columna++){
                sumafila=sumafila+matriz[fila][columna];
            }
            System.out.println("Suma de fila "+(fila+1)+" es "+sumafila);
        }
        System.out.println("");
        for (int columna=0;columna<5;columna++){
            sumacolumna=0;
            for (int fila=0;fila<5;fila++){
                sumacolumna=sumacolumna+matriz[fila][columna];
            }
            System.out.println("Suma de columna "+(columna+1)+" es "+sumacolumna);
        }

    }

}
