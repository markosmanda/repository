
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author marcos.españa
 */
public class Ejercicio_8_clase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        String[] alumnos = {"Francisco", "Marcos", "Laura", "Marta", "Pedro"};
        double[] primerTrimestre = {7, 10, 4, 5, 6};
        double[] segundoTrimestre = {4, 10, 10, 5, 5};
        double[] tercerTrimestre = {1, 10, 8, 2, 3};
        int posicion = 0;

        double mediaAlumno = 0;
        double sumaPrimerTrim = 0;
        double sumaSegundoTrim = 0;
        double sumaTercerTrim = 0;

        System.out.println("Listado de alumnos");
        System.out.println("*********************");
        for (int i = 0; i < alumnos.length; i++) {
            System.out.println((i + 1) + "." + alumnos[i]);
        }
        System.out.println("Introduce el alumno del que quieres saber la nota: ");
        Integer.parseInt(entrada.nextLine());

        for (int i = 0; i < alumnos.length; i++) {

        }
        for (int i = 0; i < alumnos.length; i++) {
            sumaPrimerTrim = sumaPrimerTrim + primerTrimestre[i] / alumnos.length;
            sumaSegundoTrim = sumaSegundoTrim + segundoTrimestre[i] / alumnos.length;
            sumaTercerTrim = sumaTercerTrim + tercerTrimestre[i] / alumnos.length;

        }
        System.out.println("La nota media del primer trimestre es: " + sumaPrimerTrim);
        System.out.println("La nota media del segundo trimestre es: " + sumaSegundoTrim);
        System.out.println("La nota media del tercer trimestre es: " + sumaTercerTrim);

    }

}
