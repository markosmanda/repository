/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = {6,6,6,7};
        int max = numeros[0];
        int min = numeros [0];
        int mayor=0;
        int menor=0;
        
        for (int i=0;i<numeros.length;i++){
            if (numeros[i]>max){
                max=numeros[i];
                mayor++;
            }
            if (numeros[i]<min){
                min=numeros[i];
                menor++;
            }
        }if (menor==numeros.length-1){
            System.out.println("Esta en orden decreciente");
        }else if (mayor==numeros.length-1){
            System.out.println("Esta en orden creciente");
        }else{
            System.out.println("No estan en orden");
        }
    }
    
}
