
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Scanner entrada = new Scanner (System.in);
       
       double media=0;
       double suma=0;
       int max ;
       int min ;
               
       
        
        
        for (int i=0; i<nota.length;i++){
            System.out.print("Introduce la nota: ");
                nota [i] = Integer.parseInt(entrada.nextLine());
            
        }
        
         min = nota[0];
         max = nota[0];
        for (int i=0; i<nota.length;i++){
           
            if (nota [i]>max){
                max = nota [i];
            }if (nota [i]<min){
                min = nota [i];
            }                
            suma=suma+nota [i];
            media = suma/nota.length;
            
            

        
        }
        System.out.println("");
        System.out.println("RESULTADOS");
        System.out.println("===========================");
        System.out.println("La nota media es: "+media);
        System.out.println("La nota mayor es: "+max);
        System.out.println("La nota minima es: "+min);

        
        
}
        
    
    
       
        
        
        
    }
    

