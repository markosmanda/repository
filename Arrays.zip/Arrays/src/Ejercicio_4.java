
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author marcos.españa
 */
public class Ejercicio_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        int positivo = 0;
        int numero = 0;

        int[] num = new int[10];

        for (int i = 0; i < num.length; i++) {
            System.out.print("Introduce un numero: ");
            num[i] = Integer.parseInt(entrada.nextLine());

            if (num[i] < 0) {
                break;
            }
            
               

            }for (int i = 0; i < num.length; i++) {
                if (num[i]>0){
                    System.out.println(+num[i]);
                }
            

        }
        }
        
    }

