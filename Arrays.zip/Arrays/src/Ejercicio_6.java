
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int dia;
        int mes;
        int año;
        
        System.out.print("Introduce el día: ");
        dia = Integer.parseInt(entrada.nextLine());
        System.out.print("Introduce el mes: ");
        mes = Integer.parseInt(entrada.nextLine());
        System.out.print("Introduce el año: ");
        año = Integer.parseInt(entrada.nextLine());
        
        int [] diasmes = {0,31,28,31,30,31,30,31,31,30,31,30,31};
        String[] mesesaño={"","enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","septiembre"};
    }
    
}
