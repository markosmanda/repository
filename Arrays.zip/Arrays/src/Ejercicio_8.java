
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        double [] alumno1 = {4, 3, 2};
        double [] alumno2 = {7, 5, 8};
        double [] alumno3 = {3, 6, 9};
        double [] alumno4 = {9, 7, 8};
        double [] alumno5 = {5, 6, 5};
        double suma = 0;
        int quealumno;

        double trimestre1 = alumno1[0] + alumno2[0] + alumno3[0] + alumno4[0] + alumno5[0];
        double trimestre2 = alumno1[1] + alumno2[1] + alumno3[1] + alumno4[1] + alumno5[1];
        double trimestre3 = alumno1[2] + alumno2[2] + alumno3[2] + alumno4[2] + alumno5[2];
        double nota1 = trimestre1 / 5;
        double nota2 = trimestre2 / 5;
        double nota3 = trimestre3 / 5;

        System.out.print("¿De que alumno quieres saber la nota?: ");
        quealumno = Integer.parseInt(entrada.nextLine());

        switch (quealumno) {
            case 1 -> {
                suma = 0;
                for (int i = 0; i < 3; i++) {
                    suma = suma + alumno1[i];
                }
            }
            case 2 -> {
                for (int i = 0; i <= 2; i++) {
                    suma = suma + alumno2[i];
                }
            }
            case 3 -> {
                for (int i = 0; i < 3; i++) {
                    suma = suma + alumno3[i];
                }
            }
            case 4 -> {
                for (int i = 0; i < 3; i++) {
                    suma = suma + alumno4[i];
                }
            }
            case 5 -> {
                for (int i = 0; i < 3; i++) {
                    suma = suma + alumno5[i];
                }
            }
        }
//        System.out.println(suma);
        double media = suma/3;
        System.out.printf("La nota media del alumno %d es: %.2f\n",quealumno,media);
        System.out.println("==========================================================================================================");

        System.out.println(
                "La nota media del primer trimestre es: " + nota1);
        System.out.println(
                "La nota media del segundo trimestre es: " + nota2);
        System.out.println(
                "La nota media del tercer trimestre es: " + nota3);
    }

}

