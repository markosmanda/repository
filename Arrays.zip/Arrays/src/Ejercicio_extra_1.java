
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_extra_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num=0;
        int[] numeros = {2, 4, 6, 8, 10};
        
        for (int i=0;i<numeros.length;i++){
            if (numeros[i]%2==0){
                num++;
                 
            }
            
    }if(num==numeros.length){
        System.out.println("Todos son pares");
    } else {
        System.out.println("No todos son pares");
    }

        
        
        
    }
    
}
