/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package defaul;

import java.util.Scanner;

/**
 *
 * @author marcos.españa
 */
public class Ejercicio_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner (System.in);
        int [] array = {5,2,3,9,7};
        
        ordenarArray(array);
        


        
    }public static void ordenarArray(int array[]){
        int []arrayascendente= ordenarascendente(array);
        int []arraydescendente= ordenardescendente(ordenarascendente(array));
        System.out.println("Imprimir array");
        System.out.println("=============================");
            System.out.print("Array sin ordenar: ");
            for (int i=0;i<array.length;i++){
                System.out.print(array[i]);
            }
            System.out.println("");

        

            System.out.print("Orden ascendente: ");
            for (int i=0;i<arrayascendente.length;i++){
                System.out.print(arrayascendente[i]);
            }
            
            System.out.println("");
            System.out.print("Array descendente: ");
            for (int i=0;i<arraydescendente.length;i++){
                System.out.print(arraydescendente[i]);
            }
            System.out.println("");

        }
    
    public static int []ordenarascendente(int [] array){
        int []arraynuevo=new int [array.length];
        
        for (int i=0;i<arraynuevo.length;i++){
            arraynuevo[i]=array[i];
        }
        for (int x=0;x<arraynuevo.length;x++){
            for (int i=0;i<arraynuevo.length-1;i++){
            if (arraynuevo[i]>arraynuevo[i+1]){
                int tmp= array[i+1];
                arraynuevo[i+1] = arraynuevo[i];
                arraynuevo[i]=tmp;
                
            }
            
        }
    }
        return arraynuevo;
    
    }
    
    
    
      public static int []ordenardescendente(int [] ordenarascendente){
           int []arraynuevo1=new int [ordenarascendente.length];
        
        for (int i=0;i<arraynuevo1.length;i++){
            arraynuevo1[i]=ordenarascendente[i];
        }
        for (int x=0;x<arraynuevo1.length;x++){
            for (int i=0;i<arraynuevo1.length-1;i++){
            if (arraynuevo1[i]<arraynuevo1[i+1]){
                int tmp= ordenarascendente[i+1];
                arraynuevo1[i+1] = arraynuevo1[i];
                arraynuevo1[i]=tmp;
                
            }
            
        }
    }
        return arraynuevo1;
       
    
    }
    }
    

